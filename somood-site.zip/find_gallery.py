import glob
import os
import re

for root, dirs, files in os.walk('.'):
    if any(x in root for x in ['.git', 'wp-content', 'wp-includes']):
        continue
    for f in files:
        if f.endswith('.html'):
            p = os.path.join(root, f)
            with open(p, 'r', encoding='utf-8', errors='ignore') as fp:
                c = fp.read()
            if 'elementor-widget-gallery' in c:
                rel = os.path.relpath(p, '.').replace('\\', '/')
                encoded = rel.encode('ascii', 'backslashreplace').decode('ascii')
                print(f"Gallery in: {encoded}")
